.. contents::

Introduction
============

This is a product that makes it possible to enable a gallery on all content

