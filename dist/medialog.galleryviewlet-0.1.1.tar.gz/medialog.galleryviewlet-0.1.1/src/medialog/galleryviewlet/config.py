"""Common configuration constants
"""

PROJECTNAME = 'medialog.galleryviewlet'

ADD_PERMISSIONS = {
    # -*- extra stuff goes here -*-
}
